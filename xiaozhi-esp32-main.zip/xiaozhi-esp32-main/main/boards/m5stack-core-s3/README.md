# 使用说明 


**编译**

```bash
python ./scripts/release.py m5stack-core-s3
```

如需手动编译，请参考 `m5stack-core-s3/config.json` 修改 menuconfig 对应选项。

**烧录**

```bash
idf.py flash
```

> [!NOTE]
> 进入下载模式：长按复位按键(约3秒)，直至内部指示灯亮绿色，松开按键。


 
